﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class Paciente : Persona
    {
        private string diagnostico;

        public string Diagnostico { get => diagnostico; set => diagnostico = value; }

        public Paciente(string nombre, string apellido, DateTime nacimiento, string barrioResidencia) 
            : base(nombre, apellido, barrioResidencia, nacimiento)
        {
        }

        internal override string FichaExtra()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine($"Reside en :{base.barrioResidencia}");
            sb.AppendLine($"Diagnostico: {Diagnostico}");
            return sb.ToString();
        }
    }
}
